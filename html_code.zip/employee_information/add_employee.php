<!DOCTYPE html>
<html>
<head>
        <title> Add Employee </title>
        <style>
            body {
            background-color: #FFF8DC;
            }
            h1 {
                background-color: #FFF8DC;
            }
        </style>
    </head>
    <body>
        <?php
            if (isset ($_POST['employee_name'])) {
 
            $username="root";
            $password="";
            $database="employee_information";
            $mysqli= new mysqli("localhost",$username,$password,$database);
 
        
            $Employee_Name = $_POST['employee_name'];
            $Employee_NameM = $_POST['employee_nameM'];
            $Employee_NameL = $_POST['employee_nameL'];
            $Employee_SSN = $_POST['employee_SSN'];
            $Employee_Year = $_POST['employee_Year'];
            $Employee_Address = $_POST['employee_Address'];
            $Employee_Sex = $_POST['employee_Sex'];
            $Employee_Salary = $_POST['employee_Salary'];
            $Employee_Manager = $_POST['employee_Manager'];
            $Employee_Department = $_POST['employee_Department'];

            $query="INSERT INTO Employee VALUES ('$Employee_Name','$Employee_NameM', '$Employee_NameL','$Employee_SSN' ,'$Employee_Year','$Employee_Address','$Employee_Sex' ,'$Employee_Salary' ,'$Employee_Manager' ,'$Employee_Department');";
            
            
            $result = $mysqli->query($query) or die (mysql_error());
            $mysqli->close();
            }
        ?>
        <form action="add_employee.php" method="post">
        <input type="text" name="employee_name" placeholder="First Name">
        <input type="text" name="employee_nameM" placeholder="Middle initial">
        <input type="text" name="employee_nameL" placeholder="Last Name">
        <input type="text" name="employee_SSN" placeholder="SSN">
        <input type="text" name="employee_Year" placeholder="DoB">
        <input type="text" name="employee_Address" placeholder="Address">
        <input type="text" name="employee_Sex" placeholder="Sex">
        <input type="text" name="employee_Salary" placeholder="Salary">
        <input type="text" name="employee_Manager" placeholder="Manager SSN">
        <input type="text" name="employee_Department" placeholder="Department number">
        <button> Add Employee </button>
        
        </form>
        <form action = "index.html">
            <Button> Return </Button>
        </form>
    </body>
</html>