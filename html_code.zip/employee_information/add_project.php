<!DOCTYPE html>
<html>
<head>
        <title> Add Project </title>
        <style>
            body {
            background-color: #FFF8DC;
            }
            h1 {
                background-color: #FFF8DC;
            }
        </style>
    </head>
    <body>
        <?php
            if (isset ($_POST['pname'])) {
 
            $username="root";
            $password="";
            $database="employee_information";
            $mysqli= new mysqli("localhost",$username,$password,$database);
 
        
            $PName = $_POST['pname'];
            $Pnumber = $_POST['pnumber'];
            $Plocation = $_POST['plocation'];
            $Dnum = $_POST['dnum'];
           

            $query="INSERT INTO Project VALUES ('$PName', '$Pnumber','$Plocation', '$Dnum');";
            
            
            $result = $mysqli->query($query) or die (mysql_error());
            $mysqli->close();
            }
        ?>
        <form action="add_project.php" method="post">
        <input type="text" name="pname" placeholder="Prpject name">
        <input type="text" name="pnumber" placeholder="Project number">
        <input type="text" name="plocation" placeholder="Project location">
        <input type="text" name="dnum" placeholder="Department number">
    
        <button> Add Project </button>
        
        </form>
        <form action = "index.html">
            <Button> Return </Button>
        </form>
    </body>
</html>