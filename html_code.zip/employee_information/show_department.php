<!DOCTYPE html>
<html>
    <head>
        <title> Show Departments </title>
        <style>
            body {
                background-color: #FFF8DC;
            }
            h1 {
                background-color: #FFF8DC;
            }
            </style>
    </head> 
    <body>
        <h1 style = "text-align:center;">Departments</h1>
        <?php
            $username="root";
            $password="";
            $database="employee_information";
            $mysqli= new mysqli("localhost",$username,$password,$database);
            $query="select * from department";
            $result = $mysqli->query($query);
            echo "<table border=1>";
            while ($temp = $result->fetch_assoc()){
                echo "<tr>";
                foreach ($temp as $key => $value){
                    echo "<td>$value</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
            $mysqli->close();
        ?>
        <form action = "index.html">
            <Button> Return </Button>
        </form>
    </body>
</html>
