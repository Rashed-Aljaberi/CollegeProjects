<!DOCTYPE html>
<html>
<head>
        <title> Add Department </title>
        <style>
            body {
            background-color: #FFF8DC;
            }
            h1 {
                background-color: #FFF8DC;
            }
        </style>
    </head>
    <body>
        <?php
            if (isset ($_POST['dname'])) {
 
            $username="root";
            $password="";
            $database="employee_information";
            $mysqli= new mysqli("localhost",$username,$password,$database);
 
        
            $DName = $_POST['dname'];
            $Dnumber = $_POST['dnumber'];
            $Mgr_SSN = $_POST['mgr_SSN'];
            $Mgr_Start_date = $_POST['mgr_Start_date'];
           

            $query="INSERT INTO Department VALUES ('$DName', '$Dnumber','$Mgr_SSN', '$Mgr_Start_date');";
            
            
            $result = $mysqli->query($query) or die (mysql_error());
            $mysqli->close();
            }
        ?>
        <form action="add_department.php" method="post">
        <input type="text" name="dname" placeholder="Department name">
        <input type="text" name="dnumber" placeholder="Department number">
        <input type="text" name="mgr_SSN" placeholder="Manager's SSN">
        <input type="text" name="mgr_Start_date" placeholder="Manager's start date">
    
        <button> Add Department </button>
        
        </form>
        <form action = "index.html">
            <Button> Return </Button>
        </form>
    </body>
</html>