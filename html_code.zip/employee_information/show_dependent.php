<!DOCTYPE html>
<html>
    <head>
        <title> Show Dependents </title>
        <style>
            body {
                background-color: #FFF8DC;
            }
            h1 {
                background-color: #FFF8DC;
            }
            </style>
    </head> 
    <body>
        <h1 style = "text-align:center;">Dependents</h1>
        <?php
            if (isset ($_POST['employee_nameF'])) {

            $username="root";
            $password="";
            $database="employee_information";
            $mysqli= new mysqli("localhost",$username,$password,$database);
            

            $Employee_Name = $_POST['employee_nameF'];
            $Employee_NameL = $_POST['employee_nameLa'];

            $query="select Dependent_name,Sex,Bdate,Relationship from Dependent where Essn IN (Select Ssn from employee where Fname='$Employee_Name' AND Lname='$Employee_NameL')";

            $result = $mysqli->query($query);
            echo "<table border=1>";
            while ($temp = $result->fetch_assoc()){
                echo "<tr>";
                foreach ($temp as $key => $value){
                    echo "<td>$value</td>";
                }
                echo "</tr>";

            }
            echo "</table>";
            $mysqli->close();

        }
        ?>
        <form action = "index.html">
            <Button> Return </Button>
        </form>
    </body>
</html>
