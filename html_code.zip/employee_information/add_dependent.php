<!DOCTYPE html>
<html>
<head>
        <title> Add Dependent </title>
        <style>
            body {
            background-color: #FFF8DC;
            }
            h1 {
                background-color: #FFF8DC;
            }
        </style>
    </head>
    <body>
        <?php
            if (isset ($_POST['essn'])) {
 
            $username="root";
            $password="";
            $database="employee_information";
            $mysqli= new mysqli("localhost",$username,$password,$database);
 
        
            $Essn = $_POST['essn'];
            $Dep_name = $_POST['dep_name'];
            $Sex = $_POST['sex'];
            $Bdate = $_POST['bdate'];
            $Relationship = $_POST['relationship'];
           

            $query="INSERT INTO Dependent VALUES ('$Essn', '$Dep_name','$Sex', '$Bdate','$Relationship');";
            
            
            $result = $mysqli->query($query) or die (mysql_error());
            $mysqli->close();
            }
        ?>
        <form action="add_dependent.php" method="post">
        <input type="text" name="essn" placeholder="Employee SSN">
        <input type="text" name="dep_name" placeholder="Dependent's name">
        <input type="text" name="sex" placeholder="Dependent's sex">
        <input type="text" name="bdate" placeholder="Dependent's bdate">
        <input type="text" name="relationship" placeholder="Dependent's Relationship">
        <button> Add Dependent </button>
        
        </form>
        <form action = "index.html">
            <Button> Return </Button>
        </form>
    </body>
</html>