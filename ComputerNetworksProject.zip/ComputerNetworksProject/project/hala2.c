#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include<time.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <dirent.h> 

#define MD3_NET_IMPLEMENTATION
#include "md3_net.h"

char* substring(char *destination, const char *source, int beg, int n)
{
    // extracts `n` characters from the source string starting from `beg` index
    // and copy them into the destination string
    while (n > 0)
    {
        *destination = *(source + beg);
 
        destination++;
        source++;
        n--;
    }
 
    // null terminate destination string
    *destination = '\0';
 
    // return the destination string
    return destination;
}

int run_server(unsigned short port) { 
    

    md3_net_init();
    const char *host;
    md3_net_socket_t socket,remote_socket;
    md3_net_address_t remote_addr;

    int shmid=shmget((key_t)8500, sizeof(char[20][200]), 0666|IPC_CREAT); //has the directory of the files to be sent
    char (*directories)[200];
    directories=shmat(shmid,0,0);//attaches buffer

    int shmid3=shmget((key_t)10005, sizeof(char[100][62]), 0666|IPC_CREAT); //has the corresponding files to be sent 
    char (*filenames)[62];
    filenames=shmat(shmid3,0,0);//attaches buffer

    int shmid4=shmget((key_t)7800, sizeof(char[20][20]), 0666|IPC_CREAT); //has the corresponding email IDs of who should should get the email/file 
    char (*Emails)[20];
    Emails=shmat(shmid4,0,0);//attaches buffer
    
    int shmid5=shmget((key_t)1850, 25, 0666|IPC_CREAT); //creates shared buffetr for other inter-process communication 
    char *shared_buffer=shmat(shmid5,NULL,0);//attaches buffer
    
    shared_buffer[0]=0;//shared value of number of clinets connected for ipc
    shared_buffer[1]=0;//shared value of number of files in queue (files that are saved in server but not yet sent, pending clinet)


    printf("Mail Server Starting at host: 127.0.0.1, waiting to be contacted for transferring Mail...\n");
   

    //socket and process creation
    int fpid=1;
    short clientIndex=0;//used to map a process to it's socket
    while(fpid!=0){//keeps repeating and taking new clients
        fpid=fork(); //create a new process for each socket
        while(fpid==0){ //the new child process will connect a client through a socket
            md3_net_tcp_socket_open(&socket, port+clientIndex, 0, 1);
            if (md3_net_tcp_accept(&socket, &remote_socket, &remote_addr)) {
                printf("Failed to accept connection\n");
            }
            else{
                host = md3_net_host_to_str(remote_addr.host);
                printf("Connected to client %d at %s\n",clientIndex, host);
                shared_buffer[0]++;//increase number of clients connected
                break;
            }  
        }
        if(fpid!=0){//parent process that will remain stuck in this loop and creat new processes for each new socket
            while(shared_buffer[0]==clientIndex);//parent waits while there are no new sockets
            clientIndex++;//to give each child process a diferent index
        }

    }

    


    /*from this point on, every new process has it's own clientIndex.
        This means each process is going to hanlde a different socket from the array 
        of scokets.

        so in other word, multiple processes will be running the code below concurently 
        and yet independantly. each process has no idea what the other is doing.

        this will enable the server to hanlde multiple clients at the same time */



    //log in verification
    char email[20];//holds email client sends
    printf("\tverifying client %d\n",clientIndex);
    while(1){  
        short auth=1; //holds wethier log in is succeful or not (1 being unsucceful)
        char password[20];//holds passwords client sends
        md3_net_tcp_socket_receive(&remote_socket, &email, 20);
        md3_net_tcp_socket_receive(&remote_socket, &password, 20);
        email[strcspn(email, "\n")] = 0; //removes \n
        password[strcspn(password, "\n")] = 0; //removes \n
        FILE *fptr= fopen("passwords.txt", "r");//open file that contains passwords
        
        while(1){
            char emails[20],passwords[20];//holds emails and passwords from file
            fscanf(fptr,"%s", emails);//gets email
            if(emails[1]==0)//checks if file reached end
                break;
            fscanf(fptr,"%s", passwords);//gets password
            
            printf("comapraing %s ",emails);
            printf("with %s\n",email);

            //cheacking if email matches
            short auth_email=strcmp(email,emails);//compares email from client with one from file

            //cheacking if password matches    
            if(auth_email==0){//if we get an email match
                printf("email found, comparing %s with the password %s\n",password,passwords);
                auth=strcmp(password,passwords);//then we compare it with it's respective password
                if(auth==0)//if password matches
                    printf("password matches, Authentication for client %d successful\n\n",clientIndex);
                else//if password doesn't match
                    printf("password does not match, Authentication failed\n");
                break;
            }

        
        }
        fclose(fptr);
        
        char authenticated[1];//creat string to send to clinet for conformation
        if(auth==0){//if authentication is succeful 
            authenticated[0]=0;//then send zero
            md3_net_tcp_socket_send(&remote_socket, &authenticated, 1);
            break;
        }
        else{//else 
            authenticated[0]=1;//send 1
             md3_net_tcp_socket_send(&remote_socket, &authenticated, 1);
        }
        printf("Authentication failed\n");
    }        
   




    //get if user wants to send an email or update inbox
    short in;
    md3_net_tcp_socket_receive(&remote_socket, &in, 2);        

    if(in==1){//client wants to send an email




        //reciving email:
        printf("\temail content for client %d\n",clientIndex);
        char to[20]; //holds reciver email
        char subject[20]; //holds subject
        char timing[20]; //holds time
        char body[1024]="";//holds body for output file;
        char filename[54]="";//holds the name of the output file
        char US[1]= "_";//underscore to add in the name of the file
        
        //to-
        int bytes_read= md3_net_tcp_socket_receive(&remote_socket, &to, 20);
        to[strcspn(to, "\n")] = 0; //removes \n
        printf("To: %s\n", to);
        //subject
        bytes_read = md3_net_tcp_socket_receive(&remote_socket, &subject, 20);
        printf("Subject: %s", subject);
        strcat(filename,subject); //add the subject to the name of the file
        filename[strcspn(filename, "\n")] = 0; //removes \n
        //strcat(filename,US); //adds underscore
        //time
        bytes_read = md3_net_tcp_socket_receive(&remote_socket, &timing, 30);
        strcat(filename,timing); //add the time to the name of the file
        filename[strcspn(filename, "\n")] = 0; //removes \n
        printf("Time: %s",timing);
        //body
        int repeats; //how many times the client will send parts of the body
        bytes_read = md3_net_tcp_socket_receive(&remote_socket, &repeats, 4);
        for(int i=0;i<repeats;i++){
            char bbody[6]; //holds part of the body 
            bytes_read = md3_net_tcp_socket_receive(&remote_socket, &bbody, 6); //recive part of the body
            printf("\nrecieved: %s",bbody);
            strcat(body,bbody); //add the part of body to the body
        }
        printf("\nbody: %s\n\n",body);





     
        //reciving file/attachment
        char lols[4]="";//for error handlening
        char type[4]="";//holds file type (eg:png,pdf)
        bytes_read = md3_net_tcp_socket_receive(&remote_socket, &type, 4); //reciving file type
        char file[1024*30]; //holds file
        bytes_read = md3_net_tcp_socket_receive(&remote_socket, &file, 1024*30); //reciving file
        
       





        //verifying 'to' field
        printf("\tverifying header for client %d\n",clientIndex);
        FILE *fptr= fopen("passwords.txt", "r");//open file that contains passwords
        short auth_email;//holds wethier 'to' feild is equal to reciver's email 
        while(1){
            char emails[20];//holds passwords from file
            fscanf(fptr,"%s", emails);//gets email
                if(emails[1]==0)//checks if file reached end
                    break;
            printf("comapraing %s ",emails);
            printf("with %s\n",to);
            //cheacking if email matches
            auth_email=strcmp(to,emails);//compares email from client with one from file
            if(!auth_email){//if they are equal
                break;
            }
            fscanf(fptr,"%s", emails);//gets password
        }

        if(!auth_email) //if email exists    
            printf("header verified successfully (250)\n\n\tsaving email locally for client %d\n",clientIndex);
        else //else email does not exist
            printf("email does not exist (Error550)\n\n");
            




        //sending status to sender and time stamp
        char ok[3]="250";
        char err[3]="550";
        char err2[3]="501";
        
        if(!auth_email)    
            md3_net_tcp_socket_send(&remote_socket, &ok, 3); //send 250 to sender
        else
            md3_net_tcp_socket_send(&remote_socket, &err, 3); //send error 550 to sender
        time_t t;   
        time(&t);
        md3_net_tcp_socket_send(&remote_socket, ctime(&t), 30); //send time stamp to sender






        //saving email in server
        char directory[200]; //holds directory of where the file is saved (sender)
        char directory2[200]; //holds directory of where the file is saved (reciver)
        char directory3[200]; //holds directory of where the attacment is saved (sender)
        char directory4[200]; //holds directory of where the attachment is saved (reciver)
        
        getcwd(directory,200);//get current directory of code
        getcwd(directory2,200);//get current directory of code
        getcwd(directory3,200);//get current directory of code
        getcwd(directory4,200);//get current directory of code
    
        strcat(directory,"/emails/"); //add folder name to directory
        strcat(directory2,"/emails/"); //add folder name to directory
        strcat(directory3,"/emails/"); //add folder name to directory
        strcat(directory4,"/emails/"); //add folder name to directory

        strcat(directory,email); //add folder name to directory
        strcat(directory2,to); //add folder name to directory
        strcat(directory3,email); //add folder name to directory
        strcat(directory4,to); //add folder name to directory

        strcat(directory,"/sent/");//add folder name to directory
        strcat(directory2,"/inbox/");//add folder name to directory
        strcat(directory3,"/sent/");//add folder name to directory
        strcat(directory4,"/inbox/");//add folder name to directory

        
        char attachmentName[60];//holds copy of file name before it get changed
        strcpy(attachmentName,filename); //copy file name to attachment name
        strcat(filename,".txt "); //add .txt to the name of the file
        strcat(directory,filename);//add file name to directory
        strcat(directory2,filename);//add file name to directory

        
        
        FILE *fptr2= fopen(directory, "w"); //open 'write' file with the name stored in directory
        fprintf(fptr2,"from: %s\n",email); //write the from of the email into the file
        fprintf(fptr2,"to: %s\n",to); //write the body of the email into the file
        fprintf(fptr2,"subject: %s",subject); //write the body of the email into the file
        fprintf(fptr2,"%s",body); //write the body of the email into the file
        fclose(fptr2); //close file reader
        
        fptr2= fopen(directory2, "w"); //open 'write' file with the name stored in directory
        fprintf(fptr2,"from: %s\n",email); //write the from of the email into the file
        fprintf(fptr2,"to: %s\n",to); //write the body of the email into the file
        fprintf(fptr2,"subject: %s",subject); //write the body of the email into the file
        fprintf(fptr2,"%s",body); //write the body of the email into the file
        fclose(fptr2); //close file reader

        md3_net_tcp_socket_send(&remote_socket, &filename, 54); //sends filename that contains subject and time to sender
        printf("email saved successfully\ndirectory:%s \n\n",directory2);



        //adding the email to the queue to be sent 
        strcpy(filenames[shared_buffer[1]],filename);//add filename to the array of files
        strcpy(directories[shared_buffer[1]],directory2);// add directory to array of directories
        strcpy(Emails[shared_buffer[1]],to);//add email to array of emails
        shared_buffer[1]++;//increment number of elements in queue








        //saving file
         if(type[0]!=0){ //if there is an attachment

            printf("saving attachment for client %d\n",clientIndex);

            strcat(attachmentName,type);//add file type to filename (eg: png,pdf)
            strcat(directory3,attachmentName);//add file name to directory
            strcat(directory4,attachmentName);//add file name to directory
           

            FILE *write_ptr;//file writer
            write_ptr = fopen(directory3,"wb");//open file with name stored in directory
            fwrite(file,sizeof(file),1,write_ptr);//copy the file to the output file
            fclose(write_ptr);//close file writer

            write_ptr = fopen(directory4,"wb");//open file with name stored in directory
            fwrite(file,sizeof(file),1,write_ptr);//copy the file to the output file
            fclose(write_ptr);//close file writer


            //adding the email to the queue to be sent 
            strcpy(filenames[shared_buffer[1]],attachmentName);//add filename to the array of files
            strcpy(directories[shared_buffer[1]],directory4);// add directory to array of directories
            strcpy(Emails[shared_buffer[1]],to);//add email to array of emails
            shared_buffer[1]++;//increment number of elements in queue

            printf("attachment saved successfully\n");
        }
        else{//no attachment to send
            printf("no attachment\n");
        }
    

    }












    else{//client wants to update inbox

        /* for loop that repeats while server looks for the indecies in queue
        in which the client has file he should get */
        for(int i=0;i<shared_buffer[1];i++){
            short isEmail=strcmp(Emails[i],email);//compare email of client to one in queue
            if(!isEmail){//if they are equal, then the client should get the email in this queue
                printf("found new file for client %d, sending,!\n",clientIndex);
                char still[1]="y";//indicates there is file to send

                FILE *source=fopen(directories[i],"rb");//open file
                char File[1024*30];//file to be sent to client
                fread(File,sizeof(File),1,source);//read file
                fclose(source);

                md3_net_tcp_socket_send(&remote_socket, &still, 1);//tell client he has a file to recive
                md3_net_tcp_socket_send(&remote_socket, &filenames[i], 54);//send client the name of the file/email
                md3_net_tcp_socket_send(&remote_socket, &File, 1024*30);//send client the name the file
                printf("file sent successfully\n\n");
                Emails[i][0]='/';//remove email from queue
                /*(this doesn't actually remove the email, it just changes first later and this has the same effect
                and it will be overwriten eventually) */
            }
        }
        
        char stops[1]="s";
        md3_net_tcp_socket_send(&remote_socket, &stops, 1);//tell client that there are no more emails for him
        while(1);
    }






    printf("client %d is done. closing socket\n", clientIndex);
    md3_net_socket_close(&remote_socket);
    md3_net_socket_close(&socket);  
    md3_net_shutdown();

    while(true);//only stops by control+c
    return 0;
}








int run_client( char *host, unsigned short port) {

    md3_net_init();
    printf("Mail Client starting on host: 127.0.0.1\nType name of Mail server: ");

    char Host[20];
    fgets(Host, 20, stdin);
    Host[strcspn(Host, "\n")] = 0; //removes \n
    host=Host;
    md3_net_socket_t socket;
    md3_net_tcp_socket_open(&socket, 0, 0, 0);
    md3_net_address_t address;
    if (md3_net_get_address(&address, host, port) != 0) {
        printf("Error: %s\n", md3_net_get_error());

        md3_net_socket_close(&socket);
        md3_net_shutdown();

        return -1;
    }
    if (md3_net_tcp_connect(&socket, address)) {
        printf("Failed to connect to %s:", host);
        return -1;
    }
    printf("successfully connected to %s\n\n", host);








    //email authentication
    char email[20];//email for login
    while(1){//infinte loop that breaks when log in is succeful
        printf("\tLog in\nemail: ");
        fgets(email, 20, stdin);//get email
        printf("input your password: ");
        char password[20];//holds password
        fgets(password, 20, stdin);//gets password
        md3_net_tcp_socket_send(&socket, email, 20);//sends email to server
        md3_net_tcp_socket_send(&socket, password, 20);//sends password to server
        char authenticated[1];//holds wethier log in is succeful
        md3_net_tcp_socket_receive(&socket, authenticated, 1);//recive log in status
        if(authenticated[0]==0)//if log in is succeful
            break;//break loop
        printf("Login failed. Try agin \n\n");
    }






    printf("Log in successful\n\nInput 1 to write email or Input any key to update inbox: ");
    short in;
    scanf("%hd", &in);  
    md3_net_tcp_socket_send(&socket, &in, 2);//sends condition to server




    //sending an email
    if(in==1){

        //getting email content
        printf("\n\tCompose email:\n");
        printf("To: ");
        char Hostname[20];//holds reciever email
        fgets(Hostname, 20, stdin); //becuase code skips first fgets
        fgets(Hostname, 20, stdin); //get hostname
        printf("Subject: ");
        char Subject[20]; //holds subject
        fgets(Subject, 20, stdin); //get subject
        printf("Body: ");
        char body[1024];//holds body
        fgets(body, 1024, stdin); //get body
        //getting file
        printf("File directory(or enter to skip): ");
        char Source[256];//holds directory
        fgets(Source, 256, stdin);//gets directory from input
        Source[strcspn(Source, "\n")] = 0; //removes \n






        //sending email content
        time_t t;   
        time(&t);
        md3_net_tcp_socket_send(&socket, Hostname, 20);//sending hostname
        md3_net_tcp_socket_send(&socket, Subject, 20);//sending subject
        md3_net_tcp_socket_send(&socket, ctime(&t), 30);//sending time
        //sending body as chunks
        int repeats=(strlen(body)+4)/5;//number of parts of body to be sent (the plus 4 is to make assure upper rounding)
        md3_net_tcp_socket_send(&socket, &repeats, 4);//send to server how many sends there will be
        int currentIndex=0;//beggining index of buffer to send in every iteration 
        int bodysize=5;//it's only five for testing puposes
        while(repeats>0){//send all parts of body
            char bbody[6]; //holds part of body
            substring(bbody,body,currentIndex,5);//get 5 byte long substring from body and adds it to bbody
            md3_net_tcp_socket_send(&socket, bbody, 6); //send the 5 byte substring
            printf("sent: %s\n", bbody);
            currentIndex+=5; //increment index for substring reading
            repeats--;
            if(repeats==1)//before the last iteration..
                bodysize=strlen(body)-currentIndex;//update the number of letter to copy (because the last iteration might be different)
        }






        //sending file
        if(strlen(Source)>1){
            FILE *source=fopen(Source,"rb");
            char File[1024*30];
            fread(File,sizeof(File),1,source);//read file
            fclose(source);
            char type[4]="";//type of file (eg.jpg)
            substring(type,Source,strlen(Source)-4,4);//copy file type to 'type'
            md3_net_tcp_socket_send(&socket, &type, 4);//sending filetype
            md3_net_tcp_socket_send(&socket, File, 1024*30);//sending hostname
        }
        else{
            char lol=0;
            md3_net_tcp_socket_send(&socket, &lol, 4);//sending that the user doesn't want to attcah
            md3_net_tcp_socket_send(&socket, &lol, 1);//to ensure paralism (number of sends in sender=number of recives in server)
        }







        //receiving conformation and time stamp
        char state[3];//holds conformation/error type (eg 550,250)
        char time[30];//holds time stamp for recieving email in server
        int bytes_read = md3_net_tcp_socket_receive(&socket, state, 3); //recieve conformation/error
        bytes_read = md3_net_tcp_socket_receive(&socket, time, 30); //recieve time stamp
        if(state[0]=='2') //if it starts with 2 (then it is 250)
            printf("server received email successfully at %s\n", time);
        else if(state[1]=='5')//if the second leter is 5 then it is 550 
            printf("Error550: email address doest not exist \n");
        







        //saving email localy
        char filename[60]=""; //holds txt file name
        char directory[200]; //holds directory of where the file is saved 
        getcwd(directory,200);//get current directory of code
        strcat(directory,"/");
        strcat(directory,email); //add folder name to directory
        directory[strcspn(directory, "\n")] = 0; //removes \n

        strcat(directory,"/sent/");//add second folder name to directory
        bytes_read = md3_net_tcp_socket_receive(&socket, &filename, 54);//reciving subject and time
        strcat(directory,filename);//add file name to directory
        
        FILE *fptr= fopen(directory, "w"); //open 'write' file with the name stored in filename
        
        fprintf(fptr,"from: %s",email); //write the 'from' of the email into the file
        fprintf(fptr,"to: %s",Hostname); //write the 'to' of the email into the file
        fprintf(fptr,"subject: %s",Subject); //write the subject of the email into the file
        fprintf(fptr,"%s",body); //write the body of the email into the file
        fclose(fptr); //close file reader


    }  




    else{ //updating inbox

        
        //listing email names   
        char directory[200];
        getcwd(directory,200);//get current directory of code
        strcat(directory,"/");
        strcat(directory,email); //add folder name to directory
        directory[strcspn(directory, "\n")] = 0; //removes \n
        strcat(directory,"/inbox/");//add second folder name to directory
        
        char inbox[50][200];//holds name of all files in inbox
        char unread[20]={0};//holds if the email were yet unread
        short inboxes=0;//holds number of emails displayed from inbox
        
        DIR *d;
        struct dirent *dir;
        d = opendir(directory);
        if (d) {
            while ((dir = readdir(d)) != NULL){
                char dirname[200];//holds file name of existing emails
                strcpy(dirname,dir->d_name);//copy the file name from directory/inbox into dirname
                strcpy(inbox[inboxes],dir->d_name);//copy the file name from directory/inbox into array
                if(strstr(dirname,".txt")){//checks if file is an email message
                    printf("%d. (read) %s\n",inboxes, dirname);//if it is, then display it
                    inboxes++;//increment number of emails displayes
                }
            }   
            closedir(d);
        }
       
        



        //reciving new files
        while(1){
            char still[1],filename[54],File[1024*30],directory2[200];
            strcpy(directory2,directory);


            md3_net_tcp_socket_receive(&socket, &still, 1);//recive weither if there is a new email
            if(still[0]!='y')
                break;//break if the is no new emails
            md3_net_tcp_socket_receive(&socket, &filename, 54);//recieve file name
            md3_net_tcp_socket_receive(&socket, &File, 1024*30);//recive file

            
            if(strstr(filename,".txt")){//checks if file is an email message
                printf("%d. (new unread) %s\n",inboxes,filename);//if it is, print it
                strcpy(inbox[inboxes],filename);//copy the file name into the array
                unread[inboxes]=1;//mark it as unread
                inboxes++;//increse number emails in inbox
            }

            //saving file
            strcat(directory2,filename);//add file name to directory
            FILE *write_ptr;//file writer
            write_ptr = fopen(directory2,"wb");//open file with name stored in Filename
            int sizeOfFile=sizeof(File);//size of file
            if(strstr(filename,".txt"))//checks if file is an email message
                sizeOfFile=300;

            fwrite(File,sizeOfFile,1,write_ptr);//copy the file from File to the output file
            fclose(write_ptr);//close file writer
            
        }





        //displaying email
        while(1){
            printf("\nchoose email to read\n");
            short in2;
            scanf("%hd", &in2);
            if(in2<inboxes){//checks if input is correct  
                FILE * fp;
                char * line = NULL;
                size_t len = 0;
                ssize_t read;

                char directory3[200];//holds dirctory of email to be displayed
                strcpy(directory3,directory);//copy directory 
                strcat(directory3,inbox[in2]);//add file name into directory
                
                fp = fopen(directory3, "r");
                printf("Email\n");
                while ((read = getline(&line, &len, fp)) != -1)//reads file line by line
                    printf("%s", line);//print line
                fclose(fp);
                if (line)
                    free(line);

                unread[in2]=0;//mark as read
                
                printf("input any digit to continue...");
                short in3;
                scanf("%hd", &in3);

                //redisplay the emails with updating read parameter
                for(int i=0;i<inboxes;i++)
                    if(unread[i]==0)//if read
                        printf("%d. (read) %s\n",i,inbox[i]);
                    else
                        printf("%d. (unread) %s\n",i,inbox[i]);  
            }
            else//if no email needs to be displayed
                break;
        } 
    }



    md3_net_socket_close(&socket);
    md3_net_shutdown();
    return 0;


}



int main(int argc, char **argv) {
    if (argc == 3 && strcmp(argv[1], "-server") == 0) {
        return run_server((unsigned short) atoi(argv[2]));
    } else if (argc == 3 && strcmp(argv[1], "-client") == 0) {
        return run_client("127.0.0.1",(unsigned short) atoi(argv[2]));
    }
 

    printf("Usage: hala [-server [port] or -client [port]\n");

    return 0;
}
