package project;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;


@SuppressWarnings("serial")
public class Customer_Dashboard extends JFrame implements ActionListener{

	static JButton b1=new JButton("View Available booking");
	static JButton b2=new JButton("View or cancel your booking");
	static JButton b3=new JButton("Sign out");
	Vector<Customer> customer;
	int B;
	
	
	
	public Customer_Dashboard(Vector<Customer> customer,int B) {
		
		this.customer=customer;
		this.B=B;
		
		setTitle("Customer Dashboard");
		setLayout(new GridLayout(3,1));
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		b3.setBackground(Color.red);
		b3.setOpaque(true);
		
		add(b1);
		add(b2);
		add(b3);
		
		
		
		
		
		setVisible(true);
		setSize(400,500);
		
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1)
			new booking(customer,B);
		
			
		if(e.getSource()==b2)
			new booked(customer,B);
			
		if(e.getSource()==b3)
			System.exit(0);
		
	}
	
	
	

}
