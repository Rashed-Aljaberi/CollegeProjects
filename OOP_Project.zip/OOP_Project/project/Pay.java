package project;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class Pay extends JFrame implements ActionListener{
	
	
	private static JLabel l1= new JLabel("",SwingConstants.CENTER);
	private static JLabel l2= new JLabel("",SwingConstants.CENTER);
	private static JButton b1=new JButton("Pay using miles");
	private static JButton b2=new JButton("Pay");
	private static JTextField t1=new JTextField("");
	private static String flight;
	private static int price,B,seats;
	private Vector<String> names=new Vector<String>(0);
	private static boolean payed=false;
	private static Vector<Customer> customer;
	
	@SuppressWarnings("static-access")
	public Pay(Vector<Customer> customer,int B){
		this.B=B;
		this.customer=customer;
		price=customer.elementAt(B).getPrice();
		flight=customer.elementAt(B).getFlight();
		seats=customer.elementAt(B).getSeats();
		price*=seats;
		
		payed=false;
		
		
		setTitle("Paying for "+customer.elementAt(B).getName());
		setLayout(new GridLayout(3,1));
		
		b1.setBackground(Color.green); //So that the pay button turns green, indicating it can be used 
		b1.setOpaque(true);
		b2.setBackground(Color.green); //So that the pay with miles button turns green, indicating it can be used 
		b2.setOpaque(true);
		b1.setEnabled(true);
		b2.setEnabled(true);
		
		l1.setText("Total: "+price);
		l2.setText("You have "+customer.elementAt(B).getPoints()+" miles, do you want to use them");
		t1.setText("");
		if(customer.elementAt(B).getPoints()==0) {
			l2.setText("You don't have any miles");
			b1.setBackground(Color.red); //So that the pay with miles button turns red, indicating it can't be used 
			b1.setOpaque(true);
		}
		else
			b1.addActionListener(this);
		
		b2.addActionListener(this);
		
		JPanel P1=new JPanel();
		P1.setLayout(new GridLayout(2,1));
		P1.add(l1);
		P1.add(l2);
		
		JPanel P2=new JPanel();
		P2.setLayout(new GridLayout(1,2));
		
		P2.add(b1);
		P2.add(b2);
		
		t1.setEditable(false);
		
		
		add(P1);
		add(P2);
		add(t1);
		
		setVisible(true);
		setSize(400,500);
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		
		if(e.getSource()==b1) {
			if(payed==false){
				int points=customer.elementAt(B).getPoints();
				System.out.println(points+"_"+price);
				if(price>points) {
					int prices=price-points;
					t1.setText("You payed only "+prices+" after using your miles");
					customer.elementAt(B).setPoints(0);
				}
				else {
					int point=points-price;
					t1.setText("You payed nothing in cash, you have "+point+" miles left");
					customer.elementAt(B).setPoints(point);
				}
				b1.setEnabled(false);
				b2.setEnabled(false);
				payed=true;
				for(int i=0;i<seats;i++)
					customer.elementAt(B).addFlights(flight);
				BookCustomer();
				BookFlight();
			}
			
		}
		
		if(e.getSource()==b2) {
			if(payed==false){
			t1.setText("You payed "+price+", you have a seat on flight "+flight);
			b1.setEnabled(false);
			b2.setEnabled(false);
			payed=true;
			
			for(int i=0;i<seats;i++)
				customer.elementAt(B).addFlights(flight);
			BookCustomer();
			BookFlight();
			}
			
		
				
				
	}
		
	}


	@SuppressWarnings("unused")
	private void BookCustomer() {
		
		String a="";
		try {
			
			 Scanner fin = new Scanner(new FileReader("Users.txt"));
			 while (fin.hasNext()) {
				 String name=fin.nextLine();
				 String user=fin.next();
			     String password=fin.next();
			     String Autho=fin.next();
			     String Points=fin.next();
			     String flights=fin.next();
			     String f=fin.nextLine();
			     f=fin.nextLine();
			     if(user.equals(customer.elementAt(B).getUserID()))
			     {
			    	 flights=customer.elementAt(B).getFlights();
			    	 Points=""+customer.elementAt(B).getPoints();
			     }
			     	 
				 names.add(name);
			     a+=user+" "+password+" "+Autho+" "+Points+" "+flights+" ";
			 }
		      fin.close();
		    
		} catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		System.out.println(names.toString()+"\n"+a);
		
		
		PrintWriter fout;
		try { 
			  fout = new PrintWriter(new File("Users.txt"));
			  String name=null, user=null, password=null,Autho=null,Points=null,flights=null;
			  int index=0;
			  
			  while(a.length()>1) {
				  	 name=names.elementAt(index);
				  	 index++;
				     user=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     password=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     Autho=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     Points=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
					 flights=a.substring(0,a.indexOf(" "));
					 
 			   	     String s=" ";
				   	 fout.print(name+"\n"+user+s+password+s+Autho+s+Points+s+flights+"\n------------------");
				   	 if(a.length()>1) {
					   	 a=a.substring(a.indexOf(" ")+1);
					   	 fout.println();
				   	 }
			  }
				   	 fout.close();
		  }catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
	}

	@SuppressWarnings("static-access")
	private void BookFlight() {
		String a="";
		try {
			
			 Scanner fin = new Scanner(new FileReader("flights.txt"));
			 while (fin.hasNext()) {
				 String flight=fin.next();
				 int buss=fin.nextInt();
				 int eco=fin.nextInt();
				 if(flight.equals(customer.elementAt(B).getFlight())) {
					 if(customer.elementAt(B).getclass().equals("Business")) {
						 buss-=customer.elementAt(B).getSeats();
					 }
					 else
						 eco-=customer.elementAt(B).getSeats();
				 }
			     a+=flight+" "+buss+" "+eco+fin.nextLine()+" ";
			 }
		      fin.close();
		    
		} catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		System.out.print(a);
		
		
		PrintWriter fout;
		try { 
			  fout = new PrintWriter(new File("flights.txt"));
			  String flight=null, seatsB=null, seatsA=null,from=null,to=null,date=null,time=null, distance=null,airline=null,price=null;
			  
			  
			  while(a.length()>1) {
				  
				     flight=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     seatsB=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     seatsA=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
					 from=a.substring(0,a.indexOf(" "));
					 a=a.substring(a.indexOf(" ")+1);
				     to=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     date=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				   	 time=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 distance=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 airline=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 price=a.substring(0,a.indexOf(" "));
				   	 
				   	 String s=" ";
				   	 fout.print(flight+s+seatsB+s+seatsA+s+from+s+to+s+date+s+time+s+distance+s+airline+s+price);
				   	 if(a.length()>1) {
					   	 a=a.substring(a.indexOf(" ")+1);
					   	 fout.println();
				   	 }
			  }
				   	 fout.close();
		  }catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	
		
	}
}
