package project;

import java.util.Vector;

public class Customer extends person{
	private int points,price,seats;
	String flight;
	private Vector<String> flights=new Vector<String>(0);
	private String classChosen;
	
	public Customer(String name, String UserID, String password, int points, String e) {
		super(name, UserID, password);
		authourized="no";
		this.points=points;
		
		flights(e);
		
	}
	
	public int getPoints() {
		return points;
	}
	
	public void addPoints(int a) {
		points+=a;
	}
	
	public void setPoints(int a) {
		points=a;
	}
	
	public void setPrice(int a) {
		price=a;
	}
	
	public void setFlights(String a) {
		flight=a;
	}
	public void setSeats(int a) {
		seats=a;
	}
	public String getFlight() {
		return flight;
	}
	
	public int getPrice() {
		return price;
	}
	
	public int getSeats() {
		return seats;
	}
	
	public Vector<String> getFlightsVector() {
		return flights;
	}
	
	public String getFlights() {
		String a="(";
		if(flights.size()>0)
		a+=flights.elementAt(0);
		else
			return "()";
	
		for (int i=1;i<flights.size();i++)
			a+=","+flights.elementAt(i);
		return a+")";
		
	}
	
	public void addFlights(String a) {
		flights.add(a);
	}
	
	public void deleteFlight(String a) {
		for(int i=0;i<flights.size();i++) {
			if(flights.elementAt(i).equals(a)) {
				flights.remove(i);
				break;
			}
		}
	}
	
	private void flights(String e) {
		e=e.substring(1);
		
		while(e.indexOf(",")!=-1) {
			String a=e.substring(0,e.indexOf(","));
			System.out.println(a);
			flights.add(a);
			e=e.substring(e.indexOf(",")+1);
		}
		String a=e.substring(0,e.indexOf(")"));
		
		if(e.length()>2) {
			flights.add(a);
		}
	}

	public void setClass(String classChosen) {
		this.classChosen=classChosen;
		
	}
	public String getclass() {
		return classChosen;
		
	}
	

}
