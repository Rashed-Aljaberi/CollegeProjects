package project;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

interface PrintToFile {

	abstract void print(String str);
}
@SuppressWarnings({"rawtypes","unchecked", "serial"})
public class Manager_Dashboard extends JFrame implements ActionListener{
	
	private static String [] sel= {"Select","View Flights Details","Add a Flight","Delete a Flight"}; 
	
	private static JComboBox D1 = new JComboBox(sel);
	private static JButton b1=new JButton("Sign out");
	private static JOptionPane OP= new JOptionPane();
	private static Vector<String> flights=new Vector<String>(0);
	private static int numberofflights=0;
	
	public Manager_Dashboard()  {
		
	
		
		setTitle("Manager Dashboard");
		setLayout(new GridLayout(1,1));
		
		
		
			
		
		add(D1);
		D1.addActionListener(this);
		
		add(b1);
		
		b1.setBackground(Color.red); //So that the pay with miles button turns red, indicating it can't be used 
		b1.setOpaque(true);
		b1.addActionListener(this);
		
		
		setVisible(true);
		setSize(400,500);
		
		setLayout(new GridLayout(2,1));
	}

	
	@SuppressWarnings({ "static-access", "unused" })
	@Override
	public void actionPerformed(ActionEvent e) {
		importFlights();
		
		if(e.getSource()==D1) {
			String d=(String) D1.getSelectedItem();
			
			if(d.equals("View Flights Details")){
				String[] names=new String[numberofflights];
				for(int i=0;i<numberofflights;i++) 
					names[i]=flights.elementAt(i).substring(0,flights.elementAt(i).indexOf(" "));
				
				 names = Arrays.stream(names).distinct().toArray(String[]::new);//to delete duplicate items
				 
				 String n = (String) OP.showInputDialog(null, "Pick the flight", "Details", JOptionPane.QUESTION_MESSAGE, null, names, names[0]);
				 if(!n.isEmpty()) {
					 String a=flights.elementAt(0);
					 for(int i=0;i<numberofflights;i++) 
							if(flights.elementAt(i).substring(0,flights.elementAt(i).indexOf(" ")).equals(n))
								a=flights.elementAt(i);
				    
				  	 
				     String flight=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     String seatsB=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     String seatsA=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     String from=a.substring(0,a.indexOf(" "));
					 a=a.substring(a.indexOf(" ")+1);
					 String to=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     String date=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     String time=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 String distance=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 String airline=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 String price=a;
				     
				     
				     JOptionPane.showMessageDialog(null, "Number of Business seats: "+seatsB+"\nNumber of Economy seats: "+seatsA+"\nFrom: "+from+"\nDestenation: "+to+"\nDate: "+date+"\nTime: "+time+"\nDistance: "+distance+"\nAirline: "+airline+"\nPrice: "+price, n+" Details", JOptionPane.INFORMATION_MESSAGE);
				 }		
			}
			
			if(d.equals("Add a Flight")){
				JTextField  flight=new JTextField(), seatsB=new JTextField(), seatsA=new JTextField(),from=new JTextField(),to=new JTextField(), date=new JTextField(),distance=new JTextField(),time=new JTextField(),airline=new JTextField(),price=new JTextField();
				
				Object[] message = {
				    "Flight: ", flight,
				    "Bussines seats:", seatsB,
				    "Economy seats", seatsA,
				    "from: ", from,
				    "Destination", to,
				    "Date (DD/MM/YYYY): ", date, 
				    "time (HH:MM): ", time,
				    "Airline: ", airline,
				    "Distance: (mi)", distance,
				    "price", price
				};

				int option = JOptionPane.showConfirmDialog(null, message, "Login", JOptionPane.OK_CANCEL_OPTION);
				
				if (option == JOptionPane.OK_OPTION) {
					addFlight(flight.getText()+" "+seatsB.getText()+" "+seatsA.getText()+" "+from.getText()+" "+to.getText()+" "+date.getText()+" "+time.getText()+" "+distance.getText()+"mi "+airline.getText()+" "+price.getText());
				}
				
			}
			
			if(d.equals("Delete a Flight")){
				String[] names=new String[numberofflights];
				
				
				LinkedHashSet<String> lhSet = new LinkedHashSet<String>(flights);
				flights.clear();
				flights.addAll(lhSet);//to remove duplicate items
				numberofflights=flights.size();
				
				for(int i=0;i<numberofflights;i++) 
					names[i]=flights.elementAt(i).substring(0,flights.elementAt(i).indexOf(" "));
				
				names = Arrays.stream(names).distinct().toArray(String[]::new);//to delete duplicate items
				String n="A11";
				n = (String)  JOptionPane.showInputDialog(null, "Pick the flight", "Delete", JOptionPane.QUESTION_MESSAGE, null, names, names[0]);
               System.out.println(n+" this is NNNNNNNNN");
				if(!n.isEmpty()) {
	               	DeleteFlight(n);
					flights.removeAllElements();
					numberofflights=0;
					importFlights();
                }
			}
			
		}
		if(e.getSource()==b1) {
			System.exit(0);
		}
		
		
		
	}


	private void importFlights() {
		String a="";
		try {
			
			 Scanner fin = new Scanner(new FileReader("flights.txt"));
			 while (fin.hasNext()) {
				 
			     a=fin.nextLine();
			     numberofflights++;
			     flights.add(a);
			     
			 }
		      fin.close();
		    
		} catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		System.out.print(a);
	}
	
		
	private void DeleteFlight(String flightnumber) {	
		
		PrintWriter fout;
			try { 
				  fout = new PrintWriter(new File("flights.txt"));
				  String flight=null, seatsB=null, seatsA=null,from=null,to=null,date=null,time=null,airline=null,price=null;
				  
				  int j=flights.size();
				  for(int i=0;i<j;i++) {
					  	 String a=flights.elementAt(i);
					  	 
					     flight=a.substring(0,a.indexOf(" "));
					     a=a.substring(a.indexOf(" ")+1);
					     seatsB=a.substring(0,a.indexOf(" "));
					     a=a.substring(a.indexOf(" ")+1);
					     seatsA=a.substring(0,a.indexOf(" "));
					     a=a.substring(a.indexOf(" ")+1);
						 from=a.substring(0,a.indexOf(" "));
						 a=a.substring(a.indexOf(" ")+1);
					     to=a.substring(0,a.indexOf(" "));
					     a=a.substring(a.indexOf(" ")+1);
					     date=a.substring(0,a.indexOf(" "));
					     a=a.substring(a.indexOf(" ")+1);
					   	 time=a.substring(0,a.indexOf(" "));
					   	 a=a.substring(a.indexOf(" ")+1);
					   	 airline=a.substring(0,a.indexOf(" "));
					   	 a=a.substring(a.indexOf(" ")+1);
					   	 price=a;
					   	 
					   	 String s=" ";
					   	 if(!flightnumber.equals(flight))
					   		 fout.println(flight+s+seatsB+s+seatsA+s+from+s+to+s+date+s+time+s+airline+s+price);
					   	 
			  }
				   	 fout.close();
		  }catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	
		
	}
	
	public void addFlight(String str) {
		PrintWriter fout=null;
		try { 
			fout = new PrintWriter(new FileOutputStream(new File("flights.txt"),true));
			fout.println(str);
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			fout.close();
		}
	}
}
