package project;

public class person {
	
	protected String name,UserID,password,authourized;
	
	public person(String name,String UserID, String password){ 
		this.name=name;
		this.UserID=UserID;
		this.password=password;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public void setUserID(String UserID) {
		this.UserID=UserID;
	}
	
	public void setPassword(String password) {
		this.password=password;
	}
	
	public String getName() {
		return name;
	}
	
	public String getUserID() {
		return UserID;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String toString() { 
		return null;
	}
	
}
