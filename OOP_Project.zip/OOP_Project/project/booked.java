package project;


import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

@SuppressWarnings({"serial","rawtypes","unchecked"})
public class booked extends JFrame implements ActionListener{

	
	private static String [] sel= {"Select"}; 
	
	private static JComboBox D1 = new JComboBox(sel);
	private static JLabel l1= new JLabel("Choose Flight",SwingConstants.CENTER);
	private static JButton b1=new JButton("Cancel");
	
	private static Vector<String> names=new Vector<String>(0);
	private static Vector<Customer> customer=new Vector<Customer>(0);
	private static int B;
	
	
	@SuppressWarnings("static-access")
	public booked(Vector<Customer> customer, int B){
		this.B=B;
		this.customer=customer;
	
		setTitle("Booked "+ customer.elementAt(B).getName());
		setLayout(new GridLayout(2,1));
		

		for(int i=0;i<customer.elementAt(B).getFlightsVector().size();i++)
			D1.addItem(customer.elementAt(B).getFlightsVector().elementAt(i));
		
		b1.addActionListener(this);
		D1.addActionListener(this);
		
		JPanel P1=new JPanel();
		P1.setLayout(new GridLayout(1,2));
		P1.add(l1);
		P1.add(D1);
			
		add(P1);
		add(b1);
		
		setVisible(true);
		setSize(400,500);
		
		
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
	}

	String flight = null;
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		
		if(e.getSource()==D1)
			flight=(String) D1.getSelectedItem();
			
		if(e.getSource()==b1) {
			if(!flight.equals("Select")) {
				customer.elementAt(B).deleteFlight(flight);
				updateFiles2(flight);
				updateFiles(flight);
				
				D1.removeItem(flight);
			}
		}
			

			
	}

	

	@SuppressWarnings("unused")
	private void updateFiles(String flight) {
		String a="";
		try {
			
			 Scanner fin = new Scanner(new FileReader("Users.txt"));
			 while (fin.hasNext()) {
				 String name=fin.nextLine();
				 String user=fin.next();
			     String password=fin.next();
			     String Autho=fin.next();
			     String points=fin.next();
			     String flights=fin.next();
			     String f=fin.nextLine();
			     f=fin.nextLine();
			     if(user.equals(customer.elementAt(B).getUserID())) {
			    	 flights=customer.elementAt(B).getFlights();
			    	 points=""+customer.elementAt(B).getPoints();
			     }
			     
				 names.add(name);
			     a+=user+" "+password+" "+Autho+" "+points+" "+flights+" ";
			 }
		      fin.close();
		    
		} catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		System.out.println(names.toString()+"\n"+a);
		
		
		PrintWriter fout;
		try { 
			  fout = new PrintWriter(new File("Users.txt"));
			  String name=null, user=null, password=null,Autho=null,points=null,flights=null;
			  int index=0;
			  
			  while(a.length()>1) {
				  	 name=names.elementAt(index);
				  	 index++;
				     user=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     password=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     Autho=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     points=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
					 flights=a.substring(0,a.indexOf(" "));
					 
 			   	     String s=" ";
				   	 fout.print(name+"\n"+user+s+password+s+Autho+s+points+s+flights+"\n------------------");
				   	 if(a.length()>1) {
					   	 a=a.substring(a.indexOf(" ")+1);
					   	 fout.println();
				   	 }
			  }
				   	 fout.close();
		  }catch (FileNotFoundException e) {
				e.printStackTrace();
			}		
		
	}
	
	private void updateFiles2(String b) {
		String a="";
		try {
			
			 Scanner fin = new Scanner(new FileReader("flights.txt"));
			 while (fin.hasNext()) {
				 
				 String flight=fin.next();
				 String Seats=fin.next();
				 int Aval=fin.nextInt();
				 String from=fin.next();
				 String to=fin.next();
				 String date=fin.next();
				 String time=fin.next();
				 String distance=fin.next();
				 
				 if(flight.equals(b)) {
					 Aval+=1;
					 customer.elementAt(B).addPoints(Integer.parseInt(distance.substring(0,distance.length()-2)));
				 }
				 
			     a+=flight+" "+Seats+" "+Aval+" "+from+" "+to+" "+date+" "+time+" "+distance+fin.nextLine()+" ";
			 }
		      fin.close();
		    
		} catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		
		
		
		PrintWriter fout;
		try { 
			  fout = new PrintWriter(new File("flights.txt"));
			  String flight=null, seatsB=null, seatsA=null,from=null,to=null,date=null,time=null,distance=null,airline=null,price=null;
			  
			  
			  while(a.length()>1) {
				  
				     flight=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     seatsB=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     seatsA=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
					 from=a.substring(0,a.indexOf(" "));
					 a=a.substring(a.indexOf(" ")+1);
				     to=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				     date=a.substring(0,a.indexOf(" "));
				     a=a.substring(a.indexOf(" ")+1);
				   	 time=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 distance=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 airline=a.substring(0,a.indexOf(" "));
				   	 a=a.substring(a.indexOf(" ")+1);
				   	 price=a.substring(0,a.indexOf(" "));
				   	 
				   	 String s=" ";
				   	 fout.print(flight+s+seatsB+s+seatsA+s+from+s+to+s+date+s+time+s+distance+s+airline+s+price);
				   	 if(a.length()>1) {
					   	 a=a.substring(a.indexOf(" ")+1);
					   	 fout.println();
				   	 }
			  }
				   	 fout.close();
		  }catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		
	}
	
	
}
