package project;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

@SuppressWarnings({"serial","rawtypes","unchecked"})
public class booking extends JFrame implements ActionListener,ItemListener {
	
	private static String[] from= {"Select","AbuDhabi","Dubai","London","NewYork"};
	private static String[] to= {"Select","London","AbuDhabi","Dubai","NewYork"};
	private static Vector<String> Available=new Vector<String>(0);
	private static Vector<Customer> customer;
	private static JComboBox D1 = new JComboBox(from);
	private static JComboBox D2 = new JComboBox(to);
	private static JComboBox D3 = new JComboBox();
	private static JLabel l1= new JLabel("From",SwingConstants.CENTER);
	private static JLabel l2= new JLabel("To",SwingConstants.CENTER);
	private static JLabel l3= new JLabel("Availabe",SwingConstants.CENTER);
	private static JLabel l4= new JLabel("Price:",SwingConstants.CENTER);
	private static JLabel l5= new JLabel("Choose number of seats:",SwingConstants.CENTER);
	private static JLabel l6= new JLabel("Choose class",SwingConstants.CENTER);
	private static JTextField t1=new JTextField();
	private static JButton Seats=new JButton();
	private static JButton Class=new JButton();
	private static JButton b1=new JButton("pay");
	private static boolean choosenFrom=false,choosenTo=false,payed=false;
	private static String flight,classChosen;
	private static int price,B,BusinessAval,EconomyAval;
	
	
	@SuppressWarnings("static-access")
	public booking(Vector<Customer> customer,int B) {
		this.B=B;
		this.customer=customer;
		
		setTitle("Booking for "+customer.elementAt(B).getName());
		setLayout(new GridLayout(6,1));
		
		JPanel P1=new JPanel();
		P1.setLayout(new GridLayout(2,2));
		JPanel P2=new JPanel();
		P2.setLayout(new GridLayout(1,2));
		JPanel P3=new JPanel();
		P3.setLayout(new GridLayout(1,2));
		JPanel seats=new JPanel();
		seats.setLayout(new GridLayout(1,2));
		JPanel B_C=new JPanel();
		B_C.setLayout(new GridLayout(1,2));
		
		D1.addActionListener(this);
		D2.addActionListener(this);
		D3.addItemListener(this);
		
		
		P1.add(l1);
		P1.add(D1);
		P1.add(l2);
		P1.add(D2);
		
		P2.add(l3);
		P2.add(D3);
		
		t1.setEditable(false);
		P3.add(l4);
		P3.add(t1);
		
		seats.add(l5);
		seats.add(Seats);
		
		B_C.add(l6);
		B_C.add(Class);
		
		Seats.setText("Click here");
		Class.setText("Click here");
		
		b1.addActionListener(this);
		Seats.addActionListener(this);
		Class.addActionListener(this);
		
		add(P1);
		add(P2);
		add(B_C);
		add(P3);
		
		add(seats);
		add(b1);
		
		
		
		
		
		setVisible(true);
		setSize(400,500);
		
		
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		
		
	}
	

	

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==Seats||e.getSource()==Class) {
			if(e.getSource()==Class) {
				String n="";
				String[] CLASS = null;
				if(EconomyAval >0 && BusinessAval>0){
					String[] temp= {"Economy","Business"};
					CLASS= temp;
				}
				else if(EconomyAval>0) {
					String[] temp= {"Economy"};
					CLASS= temp;
				}
				else {
					String[] temp= {"Business"};
					CLASS= temp;
				}
					
				try {
				
			     n = (String)JOptionPane.showInputDialog(null, "Pick the class (Business is addtional 500 AED)", "class", JOptionPane.QUESTION_MESSAGE, null, CLASS, CLASS[0]);
				}catch(NullPointerException ee) {
					n=CLASS[0]; //sets n to 1 if the user clicks on cancel
				}
				classChosen=n;
				if(classChosen.equals("Business")) {
					price+=500;
					customer.elementAt(B).setClass("Business");
				}
				else 
					customer.elementAt(B).setClass("Economy");
				
				t1.setText(price+" AED");
			}
			
			else{
				int n=1,seatsaval=BusinessAval;
				
				if(classChosen.equals("Economy"))
					seatsaval=EconomyAval;
				
				try {
				Integer[] numofseats=new Integer[seatsaval];
				for(int i=1;i<=seatsaval;i++) 
					numofseats[i-1]=i;
			     n = (Integer)JOptionPane.showInputDialog(null, "Pick the amount of seats", "seats", JOptionPane.QUESTION_MESSAGE, null, numofseats, numofseats[0]);
				}catch(NullPointerException ee) {
					n=1; //sets n to 1 if the user clicks on cancel
				}
			     customer.elementAt(B).setSeats(n);
			     
			}
		}
		else {
			String from = (String) D1.getSelectedItem(),to=(String) D2.getSelectedItem();
			
			
			if (e.getSource() == D1) { 
				  
	            from = (String) D1.getSelectedItem();
	            System.out.println("---"+from);
	            choosenFrom=true;
	            Available.clear();
	
	        }
			
			if (e.getSource() == D2) { 
				  
	            to = (String) D2.getSelectedItem();
	            System.out.println("---"+to);
	            choosenTo=true;
	            Available.clear();
			}
			
			
			
			
			
			if(choosenFrom==true &&choosenTo==true ) {
			
				if(e.getSource()== b1) {
					
					D3.removeAllItems();
					
					t1.setText("");
					Seats.removeActionListener(this);
					Class.removeActionListener(this);
					payed=true;
					customer.elementAt(B).setPrice(price);
					customer.elementAt(B).setFlights(flight);
					new Pay(customer,B);
					Seats.addActionListener(this);
					Class.addActionListener(this);
				}
				
				
				
				
				if(payed==false) {
					
					D3.removeAllItems();
					AvailableFlights(from,to);
				}
				
				payed=false;
			
				
			}
		}
		
		
	}
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		
		if (e.getSource() == D3) { 
			
			
			if(D3.getItemCount()>0) {
				
				
				String str=(String) D3.getSelectedItem();
				String str2=str.substring(str.lastIndexOf(" ")+1);
				String str3=str.substring(0,str.indexOf(" "));
				String str4=str.substring(str.indexOf(":")+1);
				String str5=str4.substring(str.indexOf(":")+1);
				/*
				String str6=str.substring(0,str.lastIndexOf(" "));
				str6=str.substring(0,str.lastIndexOf(" "));
				str6=str6.substring(str.lastIndexOf(" ")+1);
				*/
				
				str4=str4.substring(0,str4.indexOf(" "));
				str5=str5.substring(0,str5.indexOf(" "));
				
				
	            
	            System.out.println(str2+" AED");
	            
	            price=Integer.parseInt(str2);
	            flight=str3;
	            BusinessAval=Integer.parseInt(str4);
	            EconomyAval=Integer.parseInt(str5);
	            
	            
	            System.out.println(flight+"-");
	            
	            
			}
		}
		
		
		
	}

	
	@SuppressWarnings("unused")
	public static void AvailableFlights(String f,String t) {
		
		
		String flight=null, from=null,to=null,date=null,time=null,distance=null,airline=null;
		int seatsB=0, seatsA=0,price=0;
		
		try {
			 Scanner fin = new Scanner(new FileReader("flights.txt"));
			 
			 while (fin.hasNext()) {
				 
			     flight=fin.next();
			     seatsB=fin.nextInt();
			     seatsA=fin.nextInt();
				 from=fin.next();
			     to=fin.next();
			 
			     
			     System.out.println(from+" "+to);
			     
			     date=fin.next();
			   	 time=fin.next();
			   	 distance=fin.next();
			   	 airline=fin.next();
			   	 price=fin.nextInt();
			   	 
			   	 String a=flight+" Bussins seats:"+seatsB+" Econmomy seats:"+seatsA+" "+date+" "+time+" "+distance+" "+airline+" "+price;
		    	 System.out.println(a);
			    
			     if(from.equals(f)&&to.equals(t)&&(seatsA>0||seatsB>0)) 
			    	 Available.add(a); 
			   
			     
			 }
		      fin.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		for(int i=0;i<Available.size();i++)
			D3.addItem(Available.elementAt(i));
	    
		
	}
}
