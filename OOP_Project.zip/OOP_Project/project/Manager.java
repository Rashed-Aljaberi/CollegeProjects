package project;

public class Manager extends person{

	public Manager(String name, String UserID, String password) {
		super(name, UserID, password);
		authourized="yes";
	}

}
