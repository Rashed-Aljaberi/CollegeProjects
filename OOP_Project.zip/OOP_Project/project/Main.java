package project;

public class Main {
	
public static log_in b=new log_in();
	
@SuppressWarnings("static-access")
public static void main(String[] args) {
		
		b.Import();
			

	}
	
}
