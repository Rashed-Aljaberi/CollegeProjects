package project;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


@SuppressWarnings("serial")
public class log_in extends JFrame implements ActionListener{
	
	
	public static Vector<Customer> customer=new Vector<Customer>(0);
	public static Vector<Manager> manager=new Vector<Manager> (0);
	
	static JButton login=new JButton("Log in");
	static JButton signup=new JButton("Sign up");
	static JButton Mlogin=new JButton("Manager Log in");
	
	private static int B; // a pointer that points to the Customer who is logged
	
	private static PrintWriter fout;
	
	public log_in() {
		
		setTitle("Log in page");
		setLayout(new GridLayout(3,1));
		
		add(login);
		add(signup);
		add(Mlogin);
		
		login.addActionListener(this);
		signup.addActionListener(this);
		Mlogin.addActionListener(this);
		
		setVisible(true);
		setSize(400,500);
	}
	
	
	@SuppressWarnings("unused")
	public static void Import(){
		
		try {
			 Scanner fin = new Scanner(new FileReader("Users.txt"));
			 while (fin.hasNext()) {
			     String a=fin.nextLine();
			     String b=fin.next();
			     String c=fin.next();
			     String d=fin.next();
			     String e=fin.next();
			     String f=fin.next();
			     String g=fin.nextLine();
			     g=fin.nextLine();
			     System.out.println(a+" + "+b+" + "+c+" + "+d+" "+e);
			     
			     if(d.equals("yes"))
			    	 manager.add(new Manager(a,b,c));
			     else
			    	 customer.add(new Customer(a,b,c,Integer.parseInt(e),f));
				 
			 }
		      fin.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
	}
	
	public static void login() { //checks if someone is a member
		  
		  boolean isMember=false; //assume someone isn't a member first
		 
		  JTextField username = new JTextField();
		  JTextField password = new JPasswordField();
		  Object[] message = {
			    "Username:", username,
			    "Password:", password
			};

		  int option = JOptionPane.showConfirmDialog(null, message, "Login", JOptionPane.OK_CANCEL_OPTION);
		  
		  
		  if(option == JOptionPane.OK_OPTION) {
			  for(int i=0;i<customer.size();i++) { //loops through the list of members 
				  if(username.getText().equals(customer.get(i).getUserID())) //Checks if the username is found
					  if(password.getText().equals(customer.get(i).getPassword())) { //Checks if the passcode typed by the user corresponds to the actual passcode 
						  isMember=true; //if the password corresponds, then the user is indeed a member so condition is changed to true
						  B=i;
						  break; //loops is exited because the user has already been found
					  }  	  
			  }
			  
			  if(isMember==false) {
				  JOptionPane.showMessageDialog(null, "Username or Password wrong", "log in failed", JOptionPane.INFORMATION_MESSAGE);
			  }
			  else
				  new Customer_Dashboard(customer,B);
		  }
		  
	  } 
	
	
	
	public static void Mlogin() { //checks if someone is a manager
		  
		  boolean isManager=false; //assume someone isn't a member first
		 
		  JTextField username = new JTextField();
		  JTextField password = new JPasswordField();
		  Object[] message = {
			    "Username:", username,
			    "Password:", password
			};

		  int option = JOptionPane.showConfirmDialog(null, message, "Login", JOptionPane.OK_CANCEL_OPTION);
		  
		  
		  
		  if(option == JOptionPane.OK_OPTION) {
			  for(int i=0;i<manager.size();i++) { //loops through the list of members 
				  if(username.getText().equals(manager.get(i).getUserID())) //Checks if the username is found
					  if(password.getText().equals(manager.get(i).getPassword())) { //Checks if the passcode typed by the user corresponds to the actual passcode 
						  isManager=true; //if the password corresponds, then the user is indeed a member so condition is changed to true
						  
						  break; //loops is exited because the user has already been found
					  }
				  	  
			  }
			  if(isManager==false) {
				  JOptionPane.showMessageDialog(null, "Username or Password wrong", "log in failed", JOptionPane.INFORMATION_MESSAGE);
			  }
			  else
				  new Manager_Dashboard();
		  }
	  }
	
	
	
	public static void signup()  { //creates a user
		String UserName=null,Password=null,Name=null;
		
		while(true) {//loop to cheack if user name is taken
		  
		  JTextField username = new JTextField();
		  JTextField password = new JTextField();
		  JTextField fname = new JTextField();
		  
		  
		  Object[] message = {
			    "Username:", username,
			    "Password:", password,
			    "Name:", fname
		  };

		  int option = JOptionPane.showConfirmDialog(null, message, "Login", JOptionPane.OK_CANCEL_OPTION);
		  
		  
		  
		  if(option == JOptionPane.OK_OPTION) {
		  
		  boolean taken=false; //boolean that says whether the username is already taken or not
		  
			
			  for(int i=0;i<customer.size();i++) {//loops through all the usernames
				  if(username.getText().equals(customer.get(i).getUserID()))//check if the username is the same 
					  taken=true; //if it is the same then it is taken
				
			  }
			  
			  if(taken==false){//checks if the user name is not taken
				  UserName=username.getText();
			  	  Password=password.getText();
			      Name=fname.getText();
				  break; //breaks out the loop because it's not taken
			  }
			  else {
				  JOptionPane.showMessageDialog(null, "Username already taken, choose a new one", "sign up", JOptionPane.QUESTION_MESSAGE);
				  taken=false;//resets it to false because the loop is being reiterated
				  continue;
			  }
			  
		  }
		  else
			  break;
		  
		  }
		  
		  
		  
		  
		  Customer a=new Customer(Name,UserName,Password,0,"()");
		  customer.add(a);
		  System.out.print(customer);
		  
		  if(Name!=null&&UserName!=null&&Password!=null)
		  {
			  try { 
				  fout = new PrintWriter(new FileOutputStream(new File("Users.txt"),true));
				  fout.println(Name+"\n"+UserName+" "+Password+" no 0 ()"+"\n------------------");
			  }catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				finally {
					fout.close();
				}
		  }
		 
		  
	  }

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==login)
			login();
		
		if(e.getSource()==signup)
			signup();
		
		if(e.getSource()==Mlogin)
			Mlogin();
	}
}
