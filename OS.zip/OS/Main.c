#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(){
	char WriterPath[500];//holds directory of writer/producer proccess
	char ReaderPath[500];//holds directory of reader/consumer proccess
	char ReaderPath2[500];//holds directory of the second reader/consumer proccess (for counting semaphore)

    getcwd(WriterPath, 500);//get current directory of code and save it in WriterPath
    getcwd(ReaderPath, 500);//get current directory of code and save it in ReaderPath
    getcwd(ReaderPath2, 500);//get current directory of code and save it in ReaderPath2

    char in=0;
    while(in<'1' || in>'5'){
    	printf("Input:\n1. Lock Variables\n2. Strict Alternation\n3. Peterson's solution\n4. Binary Semaphores \n5. counting Semaphores\n");
    	scanf("%c", &in);
    }

    if(in=='1'){//Lock Variables solution
	    strcat(WriterPath,"/executables/LockVariables/LVWriter &");//add dirctory of proccess to the dirctory
	    strcat(ReaderPath,"/executables/LockVariables/LVReader");//add dirctory of proccess to the dirctory

	    system(WriterPath);//calls/executes producer proccess
		system(ReaderPath);//calls/executes consumer proccess

		//system("pkill LVWriter");//kills the proccess
	}
    
    if(in=='2'){//Strict Alternation solution
	    strcat(WriterPath,"/executables/StrictAlternation/SAWriter &");//add dirctory of proccess to the dirctory
	    strcat(ReaderPath,"/executables/StrictAlternation/SAReader");//add dirctory of proccess to the dirctory
	    
	    system(WriterPath);//calls/executes producer proccess
		system(ReaderPath);//calls/executes consumer proccess

 		//system("pkill SAWriter");//kills the proccess
	}

	if(in=='3'){//Peterson's solution
	    strcat(WriterPath,"/executables/Petersons/PWriter &");//add dirctory of proccess to the dirctory
	    strcat(ReaderPath,"/executables/Petersons/PReader");//add dirctory of proccess to the dirctory
	    
	    system(WriterPath);//calls/executes producer proccess
		system(ReaderPath);//calls/executes consumer proccess

		//system("pkill PWriter");//kills the proccess
	}

	if(in=='4'){//Binary Semaphore solution
	    strcat(WriterPath,"/executables/BinarySemaphore/BSWriter &");//add dirctory of proccess to the dirctory
	    strcat(ReaderPath,"/executables/BinarySemaphore/BSReader");//add dirctory of proccess to the dirctory
	    
	    system(WriterPath);//calls/executes producer proccess
		system(ReaderPath);//calls/executes consumer proccess

		//system("pkill BSWriter");//kills the proccess
	}	
	
	if(in=='5'){//Binary Semaphore solution
		strcat(WriterPath,"/executables/CountingSemaphore/CSWriter &");//add dirctory of proccess to the dirctory
	    strcat(ReaderPath,"/executables/CountingSemaphore/CSReader1 &");//add dirctory of proccess to the dirctory
	    strcat(ReaderPath2,"/executables/CountingSemaphore/CSReader2");//add dirctory of proccess to the dirctory
	    
	    system(WriterPath);//calls/executes producer proccess
		system(ReaderPath);//calls/executes consumer proccess
		system(ReaderPath2);//calls/executes 2nd consumer proccess
		
		//system("pkill CSWriter");//kills the proccess
		//system("pkill CSReader1");//kills the proccess
	
	}
	
 	

	return 0;
}