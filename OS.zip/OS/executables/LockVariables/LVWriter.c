//Lock Variables
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>


char *shared_buffer;//shared buffer/queue
char *queued; //number of elements queued in the buffer
char *Index; //has the index of next element in queue
char *lock; //the lock variable
char *writer; //wake up status of writer
char *reader; //wake up status of reader
char Write='A'; //Things to write in buffer.

void sleeps(){
	*writer=0;
}

void wakes(){
	*reader=1;
}

void crticleSection(){
	while(*queued<20){ //while buffer isn't full
		shared_buffer[(*queued+*Index)%20]=Write; //round-robin algorithim to decide where to place in buffer
		printf("wrote %c\n",Write);
		(*queued)++; //increment number of elements in queue	
		Write++; //changes the content to write eg:changes from 'A' to 'B'
		Write=(Write-65)%26+65;//to insure the range of input stays from A-Z
	}
	printf("Buffer full\n");
}

int main(){
	

	int shmid=shmget((key_t)2350, 25, 0666|IPC_CREAT); //creates shared memory segment
	shared_buffer=shmat(shmid,NULL,0);//attaches buffer

	queued=&shared_buffer[20];//this index (20) number of elements queued in the buffer
	Index=&shared_buffer[21];//this index (21) has the index of next element in queue
	lock=&shared_buffer[22];//this index (22) has the lock variable
	writer=&shared_buffer[23];//this index (23) has the wake up status for writer
	reader=&shared_buffer[24];//this index (24) has the wake up status for reader
	
	*queued=0;
	*Index=0;
	*lock=0;
	*writer=1;
	*reader=0;


	while(1)
		if(*writer==1){ //if awake
			while(*lock!=0); //while locked
			*lock=1; 
			//critcle section
			crticleSection(); 
			//end of crticle section
			*lock=0; //flip lock varibale
			sleeps(); //producer sleeps
			wakes(); //wakes consumer
		}

	return 0;
}