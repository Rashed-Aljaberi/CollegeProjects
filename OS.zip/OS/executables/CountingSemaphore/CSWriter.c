//Binary Semaphores
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>


char *shared_buffer;//shared buffer/queue
char *printing; //has the printing order
char *mutex; //the turn variable
char *empty; //slots are available
char *full; //slots is full
char Write='A'; //Things to write in buffer.


void Wait(char *s){
	while (*s<2);
	(*s)-=2;
	
}

void Signal(char *s){
	(*s)+=2;
}

void crticleSection(){
	for(int i=0;i<20;i++){ //while buffer isn't full
		shared_buffer[i]=Write; //round-robin algorithim to decide where to place in buffer
		printf("wrote %c\n",Write);
		Write++; //changes the content to write eg:changes from 'A' to 'B'
		Write=(Write-65)%26+65;//to insure the range of input stays from A-Z

	}
	printf("buffer full\n");
		
}

int main(){
	

	int shmid=shmget((key_t)2365, 24, 0666|IPC_CREAT); //creates shared memory segment
	shared_buffer=shmat(shmid,NULL,0);//attaches buffer

	full=&shared_buffer[20];//this index (20) number of elements queued in the buffer
	printing=&shared_buffer[21];//this index (21) has the has the printing order
	mutex=&shared_buffer[22];//this index (22) has the signal variable
	empty=&shared_buffer[23];//this index (23) has the number of empty slots
	
	*printing=0;
	*mutex=2;
	*empty=2;
	*full=0;

	short iterations=0;
	while(iterations<20){//the code runs enough times	
		Wait(empty); //wait while there are no empty slots
		Wait(mutex); //wait while there is at least 1 proccess inside critcal section
		//critcle section			
		crticleSection();
		Signal(full); //increment number of full slots
		Signal(mutex); //increment number of proccesses allowed to enter
		iterations++;

	}

	
	exit(0);

	return 0;
}