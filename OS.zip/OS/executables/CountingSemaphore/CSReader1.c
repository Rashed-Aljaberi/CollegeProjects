//Strict Alternation
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>


char *shared_buffer;//shared buffer/queue
char *printing; //has the printing order
char *mutex; //the turn variable
char *empty; //slots are available
char *full; //slots is full

void Wait(char *s){
	while (*s<1);
	(*s)--;
}

void Signal(char *s){
	(*s)+=2;

}

void crticleSection(){
	for(int i=0;i<20;i++)
	 	printf("1st consumer read %c\n",shared_buffer[i]); //read next element in queue
	*printing=1;//give turn to consumer 2
	while(*printing==1);//wait for consumer 2 to finish printing
	printf("Both consumers finished reading\n");
}

int main(){
	 
	int shmid=shmget((key_t)2365, 24, 0666);
	shared_buffer=shmat(shmid,NULL,0);

	full=&shared_buffer[20];//this index (20) full slots
	printing=&shared_buffer[21];//this index (21) has the has the printing order
	mutex=&shared_buffer[22];//this index (22) has the signal variable
	empty=&shared_buffer[23];//this index (23) has empty slots

	while(1){
		Wait(full); //wait while there are no slots to read
		Wait(mutex); //wait while there is a proccess inside critcal section
		//critcle section
		crticleSection();
		Signal(empty);
		Signal(mutex);
		
	}	

	return 0;
}