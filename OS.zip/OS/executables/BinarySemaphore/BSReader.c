//Binary Semaphores
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>


char *shared_buffer;//shared buffer/queue
char *queued; //number of elements queued in the buffer
char *Index; //has the index of next element in queue
char *mutex; //the turn variable
char *empty; //available slots


void Wait(char *s){
	while (*s<1);
	(*s)--;
}

void Signal(char *s){
	(*s)++;
}

void crticleSection(){
	if(*queued>0){//while buffer isn't empty
	 	printf("read %c\n",shared_buffer[*Index]); //read next element in queue
		*Index=(*Index+1)%20; //round-robin algorithm to know buffer location of next item in queue
		
		if(*queued==1)
			printf("Buffer empty\n");
	}	
}

int main(){
	 
	int shmid=shmget((key_t)2360, 24, 0666);
	shared_buffer=shmat(shmid,NULL,0);

	queued=&shared_buffer[20];//this index (20) number of elements queued in the buffer
	Index=&shared_buffer[21];//this index (21) has the index of next element in queue
	mutex=&shared_buffer[22];//this index (22) has the signal variable
	empty=&shared_buffer[23];//this index (23) has the number of empty slots


	while(1){
		Wait(queued); //wait while there are no slots to read
		Wait(mutex); //wait while there is a proccess inside critcal section
		//critcle section
		crticleSection();
		Signal(empty);
		Signal(mutex);
	}
		
		


	return 0;
}