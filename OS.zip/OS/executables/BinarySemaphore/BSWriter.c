//Binary Semaphores
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <string.h>


char *shared_buffer; //shared buffer/queue
char *queued; //number of elements queued in the buffer
char *Index; //has the index of next element in queue
char *mutex; //the signal  variable
char *empty; //available slots
char Write='A'; //Things to write in buffer.

void Wait(char *s){
	while (*s<1);
	(*s)--;
}

void Signal(char *s){
	(*s)++;
}

void crticleSection(){
	if(*queued<20){ //while buffer isn't full
		shared_buffer[(*queued+*Index)%20]=Write; //round-robin algorithim to decide where to place in buffer
		printf("wrote %c\n",Write);
		Write++; //changes the content to write eg:changes from 'A' to 'B'
		Write=(Write-65)%26+65;//to insure the range of input stays from A-Z

		if(*queued==19) //(19 instead of 20 becuase semaphore increments the number of slots after critcle section)
			printf("Buffer full\n");
			
	}
	
		
}

int main(){
	

	int shmid=shmget((key_t)2360, 24, 0666|IPC_CREAT); //creates shared memory segment
	shared_buffer=shmat(shmid,NULL,0);//attaches buffer

	queued=&shared_buffer[20];//this index (20) number of elements queued in the buffer
	Index=&shared_buffer[21];//this index (21) has the index of next element in queue
	mutex=&shared_buffer[22];//this index (22) has the signal variable
	empty=&shared_buffer[23];//this index (23) has the number of empty slots
	
	*queued=0;
	*Index=0;
	*mutex=1;
	*empty=20;
	

	short iterations=0;
	while(iterations<300){//the code runs enough times

		Wait(empty); //wait while there are no empty slots
		Wait(mutex); //wait while there is a proccess inside critcal section
		//critcle section			
		crticleSection();
		Signal(queued); //increment number of full slots
		Signal(mutex); //increment number of proccesses allowed to enter
		
		
		iterations++;

	}

	exit(0);

	return 0;
}