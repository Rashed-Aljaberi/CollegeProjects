//Strict Alternation
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>

char *shared_buffer;//shared buffer/queue
char *queued; //number of elements queued in the buffer
char *Index; //has the index of next element in queue
char *turn; //the turn variable
char *writer; //wake up status of writer
char *reader; //wake up status of reader


void sleeps(){
	*reader=0;
}

void wakes(){
	*writer=1;
}


void crticleSection(){
	while(*queued>0){//while buffer isn't empty
	 	printf("read %c\n",shared_buffer[*Index]); //read next element in queue
		*Index=(*Index+1)%20; //round-robin algorithm to know buffer location of next item in queue
		(*queued)--; //decrement number of elements in queue
	}
	printf("Buffer is empty\n");
}

int main(){
	 
	int shmid=shmget((key_t)2348, 25, 0666);
	shared_buffer=shmat(shmid,NULL,0);

	queued=&shared_buffer[20];//this index (20) number of elements queued in the buffer
	Index=&shared_buffer[21];//this index (21) has the index of next element in queue
	turn=&shared_buffer[22];//this index (22) has the turn variable
	writer=&shared_buffer[23];//this index (23) has the wake up status for writer
	reader=&shared_buffer[24];//this index (24) has the wake up status for reader


	while(1)
		if(*reader==1){ //if awake
			while(*turn!=1);//wait while turn = 0 
			//critcle section
			crticleSection();
			//end of crticle section
			*turn=0;//flip turn varibale
			sleeps(); //consumer sleeps
			wakes(); //wakes producer
		}
		
		


	return 0;
}